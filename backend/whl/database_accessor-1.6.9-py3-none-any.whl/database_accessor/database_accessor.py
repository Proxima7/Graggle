import base64
import io
import os
import queue
import threading
import time
import uuid
from typing import Optional, Dict, Union, List, Tuple, Any, Callable

import cv2
import numpy as np
import pymongo.errors
from minio import Minio
from pymongo import MongoClient

from grandpa.node import Node
from pymongo.collection import Collection

from .utils.vault_reader import read_value


class MongoDBInterface(Node):
    def __init__(self, mongo_instance: str = "dev", con_string_name: str = "mongodb_con_string_admin", **kwargs):
        super().__init__(**kwargs)
        self.mongo_instance = mongo_instance
        assert mongo_instance in ["dev", "prod"], "mongo_instance must be either 'dev' or 'prod'"
        self.mongodb_con_string = read_value(f"{mongo_instance}_{con_string_name}", vault=mongo_instance)
        self.minio_dev_access_key = read_value("dev_s3_access_key", vault="dev")
        self.minio_dev_secret_key = read_value("dev_s3_secret_key", vault="dev")
        self.minio_dev_host = read_value("dev_s3_host", vault="dev")
        self.minio_prod_access_key = read_value("prod_s3_access_key", vault="prod")
        self.minio_prod_secret_key = read_value("prod_s3_secret_key", vault="prod")
        self.minio_prod_host = read_value("prod_s3_host", vault="prod")
        self.client = MongoClient(self.mongodb_con_string)
        if os.getenv("CLUSTER_RUN"):
            self.read_client = MongoClient(self.mongodb_con_string +
                                           "&readPreference=nearest&readPreferenceTags=nodeType:ANALYTICS")
        else:
            self.read_client = MongoClient(self.mongodb_con_string + "&readPreference=nearest")
        if all([self.minio_dev_access_key, self.minio_dev_secret_key, self.minio_dev_host]):
            if os.getenv("CLUSTER_RUN"):
                self.minio_client_dev = Minio("minio.tenant-0.svc.cluster.local", access_key=self.minio_dev_access_key,
                                              secret_key=self.minio_dev_secret_key, secure=False)
            else:
                self.minio_client_dev = Minio(self.minio_dev_host, access_key=self.minio_dev_access_key,
                                              secret_key=self.minio_dev_secret_key)
        else:
            self.minio_client_dev = None
        if all([self.minio_prod_access_key, self.minio_prod_secret_key, self.minio_prod_host]):
            self.minio_client_prod = Minio(self.minio_prod_host, access_key=self.minio_prod_access_key,
                                           secret_key=self.minio_prod_secret_key)
        else:
            self.minio_client_prod = None

    def list_collection_names(self, db: str):
        db = self.read_client[db]
        collection_names = db.list_collection_names()
        return [c_name for c_name in collection_names if
                all([ext not in c_name for ext in [".chunks", ".files", ".hashes"]])]

    def get_count(self, db: str, collection: str, query: Optional[Dict] = None) -> int:
        """
        Gets the document count for the requested collection and query.

        Args:
            db: Database to get the document count for.
            collection: Collection to get the document count for.
            query: (Optional) Query to use for filtering.

        Returns:
            The estimated document count if no query is given (as this is much faster) or the calculated document count
            for the query.
        """
        coll = self.read_client[db][collection]
        if query:
            return coll.count_documents(query)
        else:
            return coll.estimated_document_count()

    def get_ids(self, db: str, collection: str, query: dict = None):
        """
        Gets the document count for the requested collection and query.

        Args:
            db: Database to get the document count for.
            collection: Collection to get the document count for.
            query: (Optional) Query to use for filtering.

        Returns:
            The estimated document count if no query is given (as this is much faster) or the calculated document count
            for the query.
        """
        try:
            return self.get_key(db=db, collection=collection, key="_id", query=query)
        except pymongo.errors.OperationFailure:
            coll = self.read_client[db][collection]
            if not query:
                return [x["_id"] for x in list(coll.aggregate([{"$group": {"_id": '$_id'}}]))]
            else:
                return [x["_id"] for x in list(coll.aggregate([{"$match": query},
                                                               {"$group": {"_id": '$_id'}}]))]

    def get_key(self, db: str, collection: str, key: str, query: dict = None):
        """
        Gets the document count for the requested collection and query.

        Args:
            db: Database to get the document count for.
            collection: Collection to get the document count for.
            key: Key to get the values for.
            query: (Optional) Query to use for filtering.

        Returns:
            The estimated document count if no query is given (as this is much faster) or the calculated document count
            for the query.
        """
        coll = self.read_client[db][collection]
        try:
            if query:
                return list(coll.find(query).distinct(key))
            else:
                return list(coll.find().distinct(key))
        except pymongo.errors.OperationFailure:
            if not query:
                return list(set([x["_id"] for x in list(coll.aggregate([{"$group": {"_id": f'${key}'}}]))]))
            else:
                return list(set([x["_id"] for x in list(coll.aggregate([{"$match": query},
                                                               {"$group": {"_id": f'${key}'}}]))]))

    def get_data(self, db: str, collection: str, return_images: bool = True, query: dict = None, doc_count: int = None,
                 random_sample: bool = False, sort_key: str = None, sort_order: int = pymongo.ASCENDING, skip_count: int = 0) -> list:
        """
        Reads the data from the requested collection.

        Args:
            db: Database to read the data from.
            collection: Collection to read the data from.
            return_images: (Optional) Whether to return the images as numpy arrays or as minio reference strings.
            query: (Optional) Query to use for filtering.
            doc_count: (Optional) Number of documents to return.
            random_sample: (Optional) Whether to return random sample of documents (only relevant if doc_count is set).
            sort_key: (Optional) Key to sort the documents by.
            sort_order: (Optional) Order to sort the documents by.

        Returns:
            The documents from the requested collection.
        """
        coll = self.read_client[db][collection]
        result = self.get_result(coll, query, doc_count, random_sample, sort_key, sort_order, skip_count)
        if return_images:
            return self.__get_images(result)
        else:
            return result

    @staticmethod
    def get_result(coll: Collection, query: Union[None, Dict] = None, doc_count: Union[None, int] = None,
                   random_sample: bool = False, sort_key: str = None,
                   sort_order: int = pymongo.ASCENDING, skip_count: int = 0) -> List[Dict]:
        """
        Gets the result from the requested collection.

        Args:
            coll: Collection to read the data from.
            query: (Optional) Query to use for filtering.
            doc_count: (Optional) Number of documents to return.
            random_sample: (Optional) Whether to return random sample of documents (only relevant if doc_count is set).
            sort_key: (Optional) Key to sort the documents by.
            sort_order: (Optional) Order to sort the documents by.

        Returns:
            The documents from the requested collection.
        """
        if query is None:
            query = {}
        if random_sample:
            assert doc_count is not None, "doc_count must be specified when random_sample is True"
            aggregation: List[Dict] = [{'$match': query}, {'$sample': {'size': doc_count}}]
            if sort_key is not None:
                aggregation.append({'$sort': {sort_key: sort_order}})
            cursor = coll.aggregate(aggregation)
            return list(cursor)
        else:
            cursor = coll.find(query).skip(skip_count)
            if sort_key is not None:
                cursor = cursor.sort(sort_key, sort_order)
            if doc_count is not None:
                return list(cursor.limit(doc_count))
            else:
                return list(cursor)

    def __get_images(self, results: list) -> list:
        """
        Gets the images from the results.

        Args:
            results: Results to get the images from.

        Returns:
            The results with the images replaced by the image data.
        """
        for i, result in enumerate(results):
            for k in results[i]:
                if "image" in k:
                    results[i][k] = self.get_image(result[k])
                elif "bytes" in k:
                    results[i][k] = self.get_bytes(result[k])
        return results

    @staticmethod
    def __parse_minio_ref(minio_ref: str) -> Tuple[str, str, str]:
        """
        Parses the minio reference string into host, bucket and key.

        Args:
            minio_ref: Minio reference string.

        Returns:
            The host, bucket and key.
        """
        minio_ref = minio_ref.replace("https://", "")
        host, bucket, key = minio_ref.split("/", maxsplit=2)
        return host, bucket, key

    def get_image(self, minio_ref: str) -> np.ndarray:
        """
        Gets the image from the minio reference string.

        Args:
            minio_ref: Minio reference string.

        Returns:
            The image as numpy array.
        """
        host, bucket, key = self.__parse_minio_ref(minio_ref)
        if host == self.minio_dev_host:
            assert self.minio_client_dev is not None, "Minio dev client is not configured. Please set the required " \
                                                      "environment variables."
            minio_client = self.minio_client_dev
        elif host == self.minio_prod_host:
            assert self.minio_client_prod is not None, "Minio prod client is not configured. Please set the required " \
                                                       "environment variables."
            minio_client = self.minio_client_prod
        else:
            raise ValueError(f"Unknown host {host}. Please check the minio host environment variables.")
        data = minio_client.get_object(bucket, key).read()
        image = np.asarray(bytearray(data), dtype="uint8")
        image = cv2.imdecode(image, cv2.IMREAD_COLOR)
        if image is None:
            data = base64.b64decode(data)
            image = np.asarray(bytearray(data), dtype="uint8")
            image = cv2.imdecode(image, cv2.IMREAD_COLOR)
        return image

    def get_bytes(self, minio_ref: str) -> np.ndarray:
        """
        Gets the bytes from the minio reference string.

        Args:
            minio_ref: Minio reference string.

        Returns:
            The bytes read from minio.
        """
        host, bucket, key = self.__parse_minio_ref(minio_ref)
        if host == self.minio_dev_host:
            assert self.minio_client_dev is not None, "Minio dev client is not configured. Please set the required " \
                                                      "environment variables."
            minio_client = self.minio_client_dev
        elif host == self.minio_prod_host:
            assert self.minio_client_prod is not None, "Minio prod client is not configured. Please set the required " \
                                                       "environment variables."
            minio_client = self.minio_client_prod
        else:
            raise ValueError(f"Unknown host {host}. Please check the minio host environment variables.")
        data = minio_client.get_object(bucket, key).read()
        return data

    def insert_image(self, image: np.ndarray, db: str, collection: str) -> str:
        """
        Inserts the image into the requested collection.

        Args:
            image: Image to insert.
            db: Database to insert the image into.
            collection: Collection to insert the image into.

        Returns:
            The minio reference string.
        """
        host = self.minio_dev_host if self.mongo_instance == "dev" else self.minio_prod_host
        bucket = db
        key = f"{collection}/{str(uuid.uuid4()).replace('-', '')}.png"
        if host == self.minio_dev_host:
            assert self.minio_client_dev is not None, "Minio dev client is not configured. Please set the required " \
                                                      "environment variables."
            minio_client = self.minio_client_dev
        else:
            assert self.minio_client_prod is not None, "Minio prod client is not configured. Please set the required " \
                                                       "environment variables."
            minio_client = self.minio_client_prod
        if not minio_client.bucket_exists(bucket):
            minio_client.make_bucket(bucket)
        _, image = cv2.imencode(".png", image)
        minio_client.put_object(bucket, key, io.BytesIO(image), len(image))
        return f"https://{host}/{bucket}/{key}"

    def insert_bytes(self, data: bytes, db: str, collection: str) -> str:
        """
        Inserts the bytes into the requested collection.

        Args:
            data: Bytes to insert.
            db: Database to insert the image into.
            collection: Collection to insert the image into.

        Returns:
            The minio reference string.
        """
        host = self.minio_dev_host if self.mongo_instance == "dev" else self.minio_prod_host
        bucket = db
        key = f"{collection}/{str(uuid.uuid4()).replace('-', '')}"
        if host == self.minio_dev_host:
            assert self.minio_client_dev is not None, "Minio dev client is not configured. Please set the required " \
                                                      "environment variables."
            minio_client = self.minio_client_dev
        else:
            assert self.minio_client_prod is not None, "Minio prod client is not configured. Please set the required " \
                                                       "environment variables."
            minio_client = self.minio_client_prod
        if not minio_client.bucket_exists(bucket):
            minio_client.make_bucket(bucket)
        minio_client.put_object(bucket, key, io.BytesIO(data), len(data))
        return f"https://{host}/{bucket}/{key}"

    def insert_images(self, data: List[Dict[str, Any]], db: str, collection: str) -> List[Dict[str, Any]]:
        """
        Inserts the images into the requested collection.

        Args:
            data: Data containing the images to insert.
            db: Database to insert the images into.
            collection: Collection to insert the images into.

        Returns:
            The data with the images replaced by the minio reference strings.
        """
        for i, dp in enumerate(data):
            for k in dp:
                if "image" in k:
                    if type(dp[k]) is not str:
                        dp[k] = self.insert_image(dp[k], db, collection)
                elif "bytes" in k:
                    if type(dp[k]) is not str:
                        dp[k] = self.insert_bytes(dp[k], db, collection)
        return data

    def insert_data(self, data: Union[Dict, List[Dict]], db: str, collection: str) -> List[str]:
        """
        Inserts the data into the requested collection.

        Args:
            data: Data to insert.
            db: Database to insert the data into.
            collection: Collection to insert the data into.

        Returns:
            The inserted ids.
        """
        if type(data) is dict:
            data = [data]
        for i in range(len(data)):
            if "_id" in data[i]:
                del data[i]["_id"]
        coll = self.client[db][collection]
        data = self.insert_images(data, db, collection)
        result = coll.insert_many(data)
        return result.inserted_ids

    def __update_image(self, data: dict, db: str, collection: str) -> dict:
        """
        Checks if there is a new image in the update data.

        Args:
            data: Data used for update.
            db: Database to update the data in.
            collection: Collection to update the data in.

        Returns:
            The data with the image replaced by the minio reference string.
        """
        for k in data:
            if "image" in k:
                if type(data[k]) is not str:
                    data[k] = self.insert_image(data[k], db, collection)
            elif "bytes" in k:
                if type(data[k]) is not str:
                    data[k] = self.insert_bytes(data[k], db, collection)
        return data

    def update_data(self, _id: str, data: dict, db: str, collection: str) -> int:
        """
        Updates the data in the requested collection.

        Args:
            _id: Id of the data to update.
            data: Data to update.
            db: Database to update the data in.
            collection: Collection to update the data in.

        Returns:
            The number of modified documents.
        """
        coll = self.client[db][collection]
        data = self.__update_image(data, db, collection)
        result = coll.update_one({"_id": _id}, {"$set": data})
        return result.modified_count

    def delete_data(self, db: str, collection: str, query: dict):
        """
        Deletes the data from the requested collection.

        Args:
            db: Database to delete the data from.
            collection: Collection to delete the data from.
            query: Query to filter the data.
        """
        coll = self.client[db][collection]
        coll.delete_many(query)

    def run(self, db: str, collection: str, return_images: bool = True, query: dict = None, doc_count: int = None,
            random_sample: bool = False) -> list:
        """
        Runs the data retrieval.

        Args:
            db: Database to retrieve the data from.
            collection: Collection to retrieve the data from.
            return_images: Whether to return the images or not.
            query: Query to filter the data.
            doc_count: Number of documents to retrieve.
            random_sample: Whether to retrieve a random sample of documents.

        Returns:
            The retrieved data.
        """
        return self.get_data(db, collection, return_images, query, doc_count, random_sample)


class MongoDBIterator(MongoDBInterface):
    def __init__(self, iter_db: str, iter_col: str, ignore_db: str = None, ignore_col: str = None,
                 return_images: bool = True, filter_query: dict = None, mongo_instance: str = "dev",
                 con_string_name: str = "mongodb-con-string-admin", **kwargs):
        super().__init__(mongo_instance, con_string_name, **kwargs)
        self.iter_db = iter_db
        self.iter_col = iter_col
        self.ignore_db = ignore_db
        self.ignore_col = ignore_col
        all_ids = self.get_ids(db=self.iter_db, collection=self.iter_col, query=filter_query)
        if self.ignore_db is not None and self.ignore_col is not None:
            ignore_ids = self.get_key(db=self.ignore_db, collection=self.ignore_col, key="entry_id")
            all_ids = list(set(all_ids) - set(ignore_ids))
        elif self.ignore_db is not None or self.ignore_col is not None:
            raise ValueError("Please provide both ignore_db and ignore_col or neither.")
        self.processable_ids = all_ids
        self.iter_counter = 0
        self.return_images = return_images
        self.t_lock = threading.Lock()

    def __len__(self):
        return len(self.processable_ids)

    def __getitem__(self, item: int):
        return self.get_data(db=self.iter_db, collection=self.iter_col, query={"_id": self.processable_ids[item]},
                             return_images=self.return_images)[0]

    def __iter__(self):
        return self

    def __next__(self):
        if self.iter_counter < len(self):
            with self.t_lock:
                loc_iter_counter = self.iter_counter
                self.iter_counter += 1
            data = self[loc_iter_counter]
            return data
        else:
            raise StopIteration

    def get_all_data(self):
        tasks = []
        for i in range(len(self)):
            task = self.switch.execute_task(target=lambda x: self[x], args=(i,))
            tasks.append(task)
        return [task.get_result() for task in tasks]

    def __insert_data_into_queue(self, data_queue: queue.Queue, index: int, max_queue_size: int = 1000):
        while data_queue.qsize() >= max_queue_size:
            time.sleep(0.1)
        data_queue.put(self[index])

    def get_all_data_queue(self, max_queue_size: int = 1000):
        res_queue = queue.Queue()
        for i in range(len(self)):
            self.switch.execute_task(self.__insert_data_into_queue, res_queue, i, max_queue_size)
        return res_queue

    def run_callback_all_data(self, callback: Callable, *args, **kwargs):
        tasks = []
        for i in range(len(self)):
            task = self.switch.execute_task(lambda x, cb, *args, **kwargs: cb(self[x], *args, **kwargs),
                                            i, callback, *args, **kwargs)
            tasks.append(task)
        return [task.get_result() for task in tasks]

    def __run_callback_and_insert_into_queue(self, res_queue: queue.Queue, index: int, callback: Callable,
                                             max_queue_size: int = 1000, *args, **kwargs):
        while res_queue.qsize() >= max_queue_size:
            time.sleep(0.1)
        res_queue.put(callback(self[index], *args, **kwargs))

    def run_callback_all_data_queue(self, callback: Callable, max_queue_size: int = 1000, *args, **kwargs):
        res_queue = queue.Queue()
        for i in range(len(self)):
            self.switch.execute_task(self.__run_callback_and_insert_into_queue, res_queue, i, callback, max_queue_size,
                                     *args, **kwargs)
        return res_queue


