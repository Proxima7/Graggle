from grandpa import GraphRuntime

from database_accessor import MongoDBInterface, MongoDBIterator
from database_accessor.graphs import default_mongo_accessor_graph, default_mongo_iterator_graph


def get_db_accessor(mongo_instance: str = "dev", con_string_name: str = "mongodb_con_string_admin") -> MongoDBInterface:
    """
    Gets an instance of the MongoDBInterface class

    Args:
        mongo_instance: Whether to use the dev or prod database (relevant for key vault selection)
        con_string_name: The name of the connection string in the key vault

    Returns:
        An instance of the MongoDBInterface class
    """
    settings = {
        "mongo_interface": {
            "mongo_instance": mongo_instance,
            "con_string_name": con_string_name
        }
    }
    gr = GraphRuntime()
    gr.add_graph("mongo_interface", default_mongo_accessor_graph, settings)
    gr.init_graph("mongo_interface")
    return gr.router.get_instruction("//mongo_interface")


def get_db_iterator(iter_db: str, iter_col: str, ignore_db: str = None, ignore_col: str = None,
                    return_images: bool = True, mongo_instance: str = "dev",
                    con_string_name: str = "mongodb_con_string_admin", filter_query: dict = None) -> MongoDBIterator:
    """
    Gets an instance of the MongoDBIterator class

    Args:
        iter_db: The database to iterate over
        iter_col: The collection to iterate over
        ignore_db: The database to ignore
        ignore_col: The collection to ignore
        return_images: Whether to return images or not
        mongo_instance: Whether to use the dev or prod database (relevant for key vault selection)
        con_string_name: The name of the connection string in the key vault
        filter_query: A filter query to apply to the iterator

    Returns:
        An instance of the MongoDBIterator class
    """
    settings = {
        "mongo_interface": {
            "iter_db": iter_db,
            "iter_col": iter_col,
            "ignore_db": ignore_db,
            "ignore_col": ignore_col,
            "return_images": return_images,
            "mongo_instance": mongo_instance,
            "con_string_name": con_string_name,
            "filter_query": filter_query
        }
    }
    gr = GraphRuntime()
    gr.add_graph("mongo_iterator", default_mongo_iterator_graph, settings)
    gr.init_graph("mongo_iterator")
    return gr.router.get_instruction("//mongo_iterator")



