import os

SECRETS_PATH_PROD = os.getenv("SECRETS_PATH_PROD", "/mnt/secrets-store")
SECRETS_PATH_DEV = os.getenv("SECRETS_PATH_DEV", "/mnt/secrets-store")


def read_value(key: str, vault="dev"):
    if vault == "prod":
        secrets_path = SECRETS_PATH_PROD
    elif vault == "dev":
        secrets_path = SECRETS_PATH_DEV
    else:
        raise ValueError("Vault must be either 'prod' or 'dev'")
    orig_key = key
    if os.path.exists(secrets_path):
        key = key.replace("_", "-")
        key = key.replace(f"{vault}-", "")
        path = os.path.join(secrets_path, key)
        if os.path.exists(path):
            with open(path, "r") as fp:
                lines = fp.readlines()
            if len(lines) > 0:
                return lines[0]
        return None
    else:
        return os.getenv(orig_key)
