default_mongo_accessor_graph = {
    "mongo_interface": {
        "node": "database_accessor.MongoDBInterface",
        "node_settings": {
            "mongo_instance": "settings:mongo_interface/mongo_instance",
            "con_string_name": "settings:mongo_interface/con_string_name"
        }
    }
}

default_mongo_iterator_graph = {
    "mongo_iterator": {
        "node": "database_accessor.MongoDBIterator",
        "node_settings": {
            "iter_db": "settings:mongo_interface/iter_db",
            "iter_col": "settings:mongo_interface/iter_col",
            "ignore_db": "settings:mongo_interface/ignore_db",
            "ignore_col": "settings:mongo_interface/ignore_col",
            "return_images": "settings:mongo_interface/return_images",
            "mongo_instance": "settings:mongo_interface/mongo_instance",
            "con_string_name": "settings:mongo_interface/con_string_name",
            "filter_query": "settings:mongo_interface/filter_query"
        }
    }
}
